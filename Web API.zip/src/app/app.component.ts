import { Component } from '@angular/core';
import { EmployeeService } from './employee.service';
import { MatDatepickerInputEvent } from '@angular/material';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'jazzhr';
  employees;
  result= {
    'New':0,
    'Screening':0,
    'Interview':0,
    'Offer':0,
    'Hired':0,
    'NotHired':0
  }

  constructor(private service: EmployeeService){
    service.getEmployee().subscribe(employeesData =>{
      this.employees = employeesData;
    },
    err=>{

    },
    ()=>{
      console.log(this.employees);
    }
    );

  }  

  addEvent(type: string, event: MatDatepickerInputEvent<Date>) {
    this.result= {
      'New':0,
      'Screening':0,
      'Interview':0,
      'Offer':0,
      'Hired':0,
      'NotHired':0
    };
    let date1 = this.foramtDate(event.value);

    this.employees.forEach(element => {
      if(this.foramtDate(new Date(element.transitionedAt)) == date1){
        switch (element.statusTo) {
          case 'New':
            this.result['New']++;
            break;
          case 'Screening':
            this.result['Screening']++;
            break;
          case 'Interview':
            this.result['Interview']++;
            break;
          case 'Offer':
            this.result['Offer']++;
            break;
          case 'Hired':
            this.result['Hired']++;
            break;
          case 'Not Hired':
            this.result['NotHired']++;
            break;
          default:
            break;
        }
      }
    });



    console.log();
  }

  foramtDate(theDate){
    return theDate.toISOString().split('T')[0];
  }
  
}
